# PayFlow AI

**Autonomous treasury & payment automation platform built on Arc**

PayFlow AI enables businesses, DAOs, and individuals to automate USDC payments, payroll, vendor settlements, and treasury management using AI agents on Circle’s stablecoin-native L1.

Built for the **Encode Club × Arc Programmable Money Hackathon**  
Tracks: **Agentic Economy** + **DeFi**

---

## Live Demo

🔗 **https://payflow-2026.netlify.app**

> Testnet only • No real funds

---

## What Works Today (MVP Status)

| Feature                              | Status          | Notes |
|--------------------------------------|-----------------|-------|
| Connect any EVM wallet to Arc Testnet | ✅ Working     | Auto-adds Arc network |
| View live USDC balance               | ✅ Working     | Real balance from Arc |
| Send USDC on Arc                     | ✅ Working     | Real on-chain transfers (gas paid in USDC) |
| Dashboard & transaction history      | ✅ Working     | Mix of live + demo data |
| Agent rule configuration UI          | ✅ Working     | Rules can be viewed and edited |
| Agent API (browser + HTTP)           | ✅ Working     | `window.PayFlowAPI` + real HTTP endpoints |
| Autonomous agent execution           | 🟡 Simulated   | Full autonomy is the next phase |
| Payroll / Revenue split / Treasury   | 🟡 Demo        | Logic exists, real triggers coming |

---

## Architecture

```
User / External AI Agent
        │
        ▼
Frontend Dashboard (single-page HTML + ethers.js)
        │
        ▼
Netlify Functions (Agent API)
        │
        ├── Rule Engine (demo)
        ├── Payroll Scheduler (simulated)
        ├── Treasury Manager (demo)
        └── Revenue Splitter (demo)
        │
        ▼
Arc Blockchain (USDC as gas)
```

---

## Tech Stack

- **Blockchain**: Arc Testnet (Chain ID `5042002`)
- **Stablecoin**: USDC (native gas)
- **Frontend**: Vanilla HTML + Tailwind CSS + ethers.js v6
- **Backend / Agent API**: Netlify Functions (serverless)
- **Wallet**: Any EVM wallet (MetaMask, Rabby, Coinbase Wallet, etc.)

---

## Agent API (for external AIs)

External agents (Grok, Claude, GPT, etc.) can control PayFlow via HTTP:

```
Base URL: https://payflow-2026.netlify.app/api
```

| Method | Endpoint                  | Description                     |
|--------|---------------------------|---------------------------------|
| GET    | `/api`                    | API help & status               |
| GET    | `/api/status`             | Platform status                 |
| GET    | `/api/agents`             | List AI payment agents          |
| GET    | `/api/rules`              | List payment rules              |
| GET    | `/api/payroll`            | Payroll summary                 |
| POST   | `/api/payroll/simulate`   | Trigger payroll simulation      |
| GET    | `/api/treasury`           | Treasury allocation & health    |
| GET    | `/api/transactions`       | Recent transaction history      |
| GET    | `/api/command?q=...`      | Natural language commands       |

### Example (Claude / ChatGPT / Grok)

```
Call this API and summarize the agents:
https://payflow-2026.netlify.app/api/agents

Then simulate payroll:
POST https://payflow-2026.netlify.app/api/payroll/simulate
```

### Browser object

When the dashboard is open you can also use:

```js
window.PayFlowAPI.getStatus()
window.PayFlowAPI.listAgents()
window.PayFlowAPI.command("list agents")
```

---

## Local Development

```bash
# Clone
git clone https://github.com/mayneleo5/payflow-ai.git
cd payflow-ai

# Install Netlify CLI (optional but recommended)
npm install

# Run locally (serves frontend + functions)
npx netlify dev
```

Open http://localhost:8888

---

## Deploy to Netlify

1. Push this repo to GitHub
2. Connect the repo to Netlify
3. Build settings are already in `netlify.toml` (publish = `public`, functions = `netlify/functions`)
4. Deploy

Or drag-and-drop the whole folder into Netlify Drop for a quick deploy.

---

## Roadmap

**Phase 1 – Current**  
- Wallet connection  
- Real USDC transfers on Arc  
- Dashboard + rule configuration  
- Working Agent API (browser + HTTP)

**Phase 2**  
- Real autonomous agent execution  
- Condition-based & scheduled payments  
- Automatic revenue splitting

**Phase 3**  
- Multi-signature approvals  
- Cross-chain flows (App Kits / CCTP)  
- Deeper Agent Stack / Circle integration  
- Risk controls and spending limits

---

## Why Arc?

- USDC as gas → predictable and low costs  
- Sub-second settlement  
- Stablecoin-native infrastructure ideal for autonomous financial agents

---

## Team

**PayFlow AI**  
Built for the Encode Club × Arc Programmable Money Hackathon

---

## License

MIT
